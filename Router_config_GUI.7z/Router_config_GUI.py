from ast import Delete
from calendar import c
from cgitb import text
from ctypes import sizeof
from importlib.metadata import entry_points
from importlib.util import find_spec
from msilib.schema import CheckBox
from multiprocessing.sharedctypes import Value
from optparse import Values
from os import stat
from socket import has_dualstack_ipv6
from tkinter import *
import tkinter
import tkinter.ttk as ttk
from array import *
import tkinter.font as tkFont
from turtle import back, color
from unittest.loader import VALID_MODULE_NAME
import tkinter.messagebox as msgbox



root = Tk()
root.title("Cisco Network Configuration Generator_V 1.0.0")
root.geometry("1000x800+450+100")
root.resizable(False, False)

fontstyle = tkFont.Font(family="맑은 고딕", size=11)
boxfont = tkFont.Font(size=15)
grayfont = tkFont.Font()


#설정항목 과 종류, 버튼 설정
if_lable = Label(root, text="설정 항목 : ", font=fontstyle)
if_lable.grid(row=0 , column=0, columnspan=2, padx=5, pady=3)


opt_combobox = ttk.Combobox(root, height=10, width=30, values=["인터페이스 설정",
                                                    #"NAT 설정",
                                                    #"OSPF 설정"
                                                    ], state="readonly", font=fontstyle)
opt_combobox.set("Select type of configuration")
opt_combobox.grid(row=0, column=2)


textbox = Text(root, width=51, height=37, font=boxfont)
textbox.insert(END, "설정에 대한 Command 출력창 입니다.")
textbox.configure(state='disabled')
textbox.grid(row=0, column=5, rowspan=30, padx=5, pady=10)


def hide_frame():
    if_conf_frame.grid_forget()
    nat_conf_frame.grid_forget()
    ospf_conf_frame.grid_forget()

def select_option():
    global textbox
    global opt_combobox
    
    if opt_combobox.current() == -1:
        textbox.configure(state='normal')
        textbox.delete(1.0, END)
        textbox.insert(END, "설정 항목을 선택해 주세요.\n")
        textbox.configure(state='disabled')
    
    elif opt_combobox.get() == "인터페이스 설정":
        textbox.configure(state='normal')
        textbox.delete(1.0, END)
        hide_frame()
        textbox.insert(END, "인터페이스 설정 선택\n")
        if_conf_frame.grid(row=1, column=1, rowspan=500, columnspan=4, padx=10)
        if_conf_frame.grid_propagate(0)
        sub.delete(0, END)
        textbox.configure(state='disabled')
        sub.insert(END, "255.255.255.0")
    
    elif opt_combobox.get() == "NAT 설정":
        textbox.configure(state='normal')
        textbox.delete(1.0, END)
        hide_frame()
        nat_conf_frame.grid(row=1, column=1, rowspan=500, columnspan=4, padx=10)
        nat_conf_frame.grid_propagate(0)
        textbox.insert(END, "NAT 설정 선택\n")
        textbox.configure(state='disabled')
    
    elif opt_combobox.get() == "OSPF 설정":
        textbox.configure(state='normal')
        textbox.delete(1.0, END)
        hide_frame()
        ospf_conf_frame.grid(row=1, column=1, rowspan=500, columnspan=4, padx=10)
        ospf_conf_frame.grid_propagate(0)
        textbox.insert(END, "OSPF 설정 선택\n")
        textbox.configure(state='disabled')

#클립보드에 복사 기능
def copy():
    root.clipboard_clear()
    root.clipboard_append(textbox.get(1.0, END))

#Button        
btn1 = Button(root, text="선 택", command=select_option)
btn1.grid(row=0, column=4, padx=11)
btn2 = Button(root,text="복 사",font=fontstyle,command=copy)
btn2.place(x=935, y=762, width=50, height=27)


#인터페이스 설정 Frame    
if_conf_frame = Frame(root, width="393", height="700", bd=2, relief=RIDGE, background="light gray") 
if_conf_frame.grid_forget()
interface = Label(if_conf_frame, text="Interface", font=tkFont.Font(size=14, family="맑은 고딕"), bg="light gray")
if_conf_frame.grid_propagate(0)
interface.place(x=1, y=1)

port_la = Label(if_conf_frame, text="- FastEthernet Port :", font=fontstyle, bg="light gray")
port_la.place(x=15, y=30)
port = Entry(if_conf_frame, width=4, font=boxfont)
port.place(x=160, y=32)
port_range_s = Entry(if_conf_frame, width=4, font=boxfont)
port_range_m = Label(if_conf_frame, text="~", font=fontstyle, bg="light gray")
port_range_d = Entry(if_conf_frame, width=2, font=boxfont)

sour_ip = Label(if_conf_frame, text="- IP 주소 :", font=fontstyle, bg="light gray")
sour_ip.place(x=15, y=65)
ip = Entry(if_conf_frame, width=15, font=boxfont)
ip.place(x=95, y=66)

sub_mask = Label(if_conf_frame, text="- 서브넷 마스크 :", font=fontstyle, bg="light gray")
sub_mask.place(x=15, y=100)
sub = Entry(if_conf_frame, width=15, font=boxfont)
sub.place(x=140, y=100)

dhcp_use = Label(if_conf_frame, text="- DHCP Relay Agent", font=fontstyle, bg="light gray")
dhcp_use.place(x=15, y=170)
dhcp_ip = Label(if_conf_frame, text="Agent/DHCP IP : ", font=fontstyle, bg="light gray")
dhcp_ip.place(x=50,y=205)
dhcp = Entry(if_conf_frame, width=15, font=boxfont, bg="white")
dhcp.configure(state='disabled')
dhcp.place(x=183, y=206)

Vlan = Label(if_conf_frame, text="Vlan Port Configuration", font=tkFont.Font(size=14, family="맑은 고딕"), bg="light gray")
Vlan.place(x=1,y=250)

#vlan Frame_in if_conf_frame
vlan_conf_frame = Frame(if_conf_frame, width="375", height="350", background="light gray") 
vlan_conf_frame.place_forget()

#vlan_conf_frame.grid_propagate(0)
vlan_num = Label(vlan_conf_frame, text="- Vlan num : ", font=fontstyle, bg="light gray")
vnum = Entry(vlan_conf_frame, width=5, font=boxfont)
Mode = Label(vlan_conf_frame, text="- Mode", font=fontstyle, bg="light gray")
allowed_vlan = Label(vlan_conf_frame, text="- Allowed Vlan list", font=fontstyle, bg="light gray")
allowed_vlan_text = Text(vlan_conf_frame, width=30, height=1, font=boxfont)

def select_range():
    if port_range_chkvar.get() == 1:
        port.place_forget()
        port_range_s.place (x=160, y=32)
        port_range_m.place (x=212, y=32)
        port_range_d.place (x=232, y=32)
        port.delete(0, END)
        sub.delete(0, END)
        ip.delete(0, END)
        ip.configure(state="disabled")
        sub.configure(state="disabled")
    elif port_range_chkvar.get() == 0:
        port_range_s.place_forget()
        port_range_m.place_forget()
        port_range_d.place_forget()
        port.place(x=160, y=32)
        port_range_s.delete(0, END)
        port_range_d.delete(0, END)
        if use_vlan_chkvar.get() == 0:
            ip.configure(state="normal")
            sub.configure(state="normal")
            sub.insert(0, "255.255.255.0")

def select_chk_in():
    out_chk_btn.deselect()
    none_chk_btn.deselect()
    in_chk_btn.select()
           
def select_chk_out():
    in_chk_btn.deselect()
    none_chk_btn.deselect()
    out_chk_btn.select()

def select_chk_none():
    in_chk_btn.deselect()
    out_chk_btn.deselect()
    none_chk_btn.select()

def chk_yes():
    dhcp.place_forget()
    dhcp.place(x=183, y=206)
    dhcp.configure(state='normal')
    dhcp_chk_no.deselect()
    dhcp_chk_yes.select()
    
def chk_no():
    dhcp.place_forget()
    dhcp.place(x=183, y=206)
    dhcp.delete(0, END)
    dhcp.configure(state='disabled')
    dhcp_chk_yes.deselect()
    dhcp_chk_no.select()
    
def make_m_vlan(v_nums):
    textbox.insert(END, f"vlan {v_nums}\n")
    textbox.insert(END, "exit\n")
    
v_nums = []
    
def if_make():
    global port
    global ip
    global sub
    global dhcp
    num = port.get().strip("\n")
    num2 = ip.get().strip("\n")
    num3 = sub.get().strip("\n")
    num4 = dhcp.get().strip("\n")
    vnum1 = vnum.get().strip("\n")
    pnum1 = port_range_s.get().strip("\n")
    pnum2 = port_range_d.get().strip("\n")
    if use_vlan_chkvar.get() == 0: #Vlan 미적용시 작동
        if port_range_chkvar.get() == 1:
            if port_range_s.get() == "" or port_range_d.get() == "":
                msgbox.showwarning("info","Port 번호를 입력해주세요")
        if (num == "" or num2 == "" or num3 == "") and port_range_chkvar.get() == 0:
            if num == "":
                msgbox.showwarning("info","인터페이스 Port를 입력해주세요.")
            elif num2 == "":
                msgbox.showwarning("info","IP 주소를 입력해주세요.")
            elif num3 == "":
                msgbox.showwarning("info","Subnetmask 를 입력해주세요.")
        else:
            textbox.configure(state='normal')
            textbox.delete(1.0, END)
            if port_range_chkvar.get() == 0:
                textbox.insert(END, f"interface fastethernet {num}\n")
                textbox.insert(END, f"ip address {num2} {num3}\n")
            else:
                textbox.insert(END, f"interface range fastethernet {port_range_s.get()} - {port_range_d.get()}\n")
            if none_chkvar.get() == 0:
                if in_chkvar.get() == 1:
                    textbox.insert(END, "ip nat inside\n")
                else:
                    textbox.insert(END, "ip nat outside\n")
            if dhcp_yes_chkvar.get() == 1:
                if num4 == "":
                    msgbox.showwarning("info", "Agent 주소를 입력해주세요.")
                else:
                    textbox.insert(END, f"ip helper-address {num4}\n")
            textbox.insert(END, "no shutdown\n")
            textbox.insert(END, "exit\n")
            textbox.configure(state="disabled")
    else: #Vlan 적용시 작동
        none_chk_btn.select()
        dhcp_chk_no.select()
        if port_range_chkvar.get() == 1 and (port_range_s.get() == "" or port_range_d.get() == "" or vnum1 == ""):
            if port_range_s.get() == "" or port_range_d.get() == "":
                msgbox.showwarning("info","Port 번호를 입력해주세요")
            elif vnum1 == "":
                msgbox.showwarning("info","Vlan 번호를 입력해주세요.")
        elif port_range_chkvar.get() == 0 and (num == "" or vnum1 == ""):
            if num == "":
                msgbox.showwarning("info","인터페이스 Port를 입력해주세요.")
            elif vnum1 == "":
                msgbox.showwarning("info","Vlan 번호를 입력해주세요.")
        else:
            if acc_radbtn_var.get() == 1:
                if port_range_chkvar.get() == 0:
                    textbox.configure(state="normal")
                    textbox.delete(0.0, END)
                    textbox.insert(END, f"vlan {vnum1}\nexit\n")
                    textbox.insert(END, f"interface fastethernet {num}\n")
                    textbox.insert(END, f"switchport mode access\nswitchport access vlan {vnum1}\nexit")
                    textbox.configure(state="disabled")
                else:
                    textbox.configure(state="normal")
                    textbox.delete(0.0, END)
                    textbox.insert(END, f"vlan {vnum1}\nexit\n")
                    textbox.insert(END, f"interface range fastethernet {pnum1} - {pnum2}\n")
                    textbox.insert(END, f"switchport mode access\nswitchport access vlan {vnum1}\nexit")
                    textbox.configure(state="disabled")                    
            elif acc_radbtn_var.get() ==2:
                vv_num = str(v_nums).strip("[,]").replace(" ","")
                textbox.configure(state="normal")
                textbox.delete(0.0, END)
                for i in v_nums:
                    make_m_vlan(i)
                if port_range_chkvar.get() == 0:
                    textbox.insert(END, f"interface fastethernet {num}\n")
                else:
                    textbox.insert(END, f"interface range fastethernet {pnum1} - {pnum2}\n")
                textbox.insert(END, f"switchport mode trunk\nswitchport trunk encapsulation dot1q\n")
                textbox.insert(END, f"switchport trunk allowed vlan 1,{vv_num},1002-1005\nexit\n")
            
def if_clear():
    global v_nums
    port.delete(0, END)
    ip.delete(0, END)
    dhcp.delete(0, END)
    vnum.delete(0, END)
    v_nums = []
    sh_v_mode()
    select_chk_none()
    chk_no()
    
def show_vlan_frame():
    global v_nums
    if use_vlan_chkvar.get() == 1:
        select_chk_none()
        chk_no()
        dhcp_chk_yes.configure(state="disabled")
        in_chk_btn.configure(state="disabled")
        out_chk_btn.configure(state="disabled")
        vlan_conf_frame.place(x=8,y=281)
        sh_v_mode()
        vlan_num.place(x=1, y=3)
        vnum.place(x=99, y=5)
        Mode.place(x=1, y=38)
        acc_radbtn.place(x=90, y=37)
        trk_radbtn.place(x=200, y=37)
        ip.configure(state="disabled")
        sub.delete(0, END)
        sub.configure(state="disabled")
    else:
        dhcp_chk_yes.configure(state="normal")
        in_chk_btn.configure(state="normal")
        out_chk_btn.configure(state="normal")
        v_nums = []
        vlan_conf_frame.place_forget()
        vlan_num.place_forget()
        vnum.place_forget()
        Mode.place_forget()
        acc_radbtn.place_forget()
        trk_radbtn.place_forget()
        if port_range_chkvar.get() == 0:
            ip.configure(state="normal")
            sub.configure(state="normal")
            sub.insert(END, "255.255.255.0")

def print_allowed():
    if v_nums == []:
        allowed_vlan_text.configure(state="normal")
        allowed_vlan_text.delete(0.0, END)
        allowed_vlan_text.insert(END, f"1, 1002 - 1005")
        allowed_vlan_text.configure(state="disabled")
    else:
        num = str(v_nums).strip("[,]")
        allowed_vlan_text.configure(state="normal")
        allowed_vlan_text.delete(0.0, END)
        allowed_vlan_text.insert(END, f"1, {num}, 1002 - 1005")
        allowed_vlan_text.configure(state="disabled")
       
def add_allow_vlan():
    if vnum.get():
        if int(vnum.get()) not in v_nums:
            num = int(vnum.get())
            v_nums.append(num)
            v_nums.sort()
            print_allowed()

def del_allow_vlan():
    if vnum.get():
        num = int(vnum.get())
        v_nums.remove(num)
        print_allowed()

def sh_v_mode():
    global v_nums
    if acc_radbtn_var.get() == 2:
        if v_nums == []:
            v_add_btn.place(x=174, y=7)
            v_del_btn.place(x=224, y=7)
            allowed_vlan.place(x=26, y=65)
            allowed_vlan_text.place(x=50,y=93)
            allowed_vlan_text.configure(state="normal")
            allowed_vlan_text.delete(0.0, END)
            allowed_vlan_text.insert(END, "1, 1002 - 1005")
            allowed_vlan_text.configure(state="disabled")
            vnum.delete(0, END)
    elif acc_radbtn_var.get() == 1:
        allowed_vlan_text.configure(state="normal")
        allowed_vlan_text.delete(0.0, END)
        allowed_vlan_text.configure(state="disabled")
        v_add_btn.place_forget()
        v_del_btn.place_forget()
        allowed_vlan.place_forget()
        allowed_vlan_text.place_forget()
        v_nums = []
        vnum.delete(0, END)
 
#vlan Button
acc_radbtn_var = tkinter.IntVar()
acc_radbtn = Radiobutton(vlan_conf_frame, text="Access Port", value=1, variable=acc_radbtn_var, bg="light gray", command=sh_v_mode)
trk_radbtn = Radiobutton(vlan_conf_frame, text="Trunk Port", value=2, variable=acc_radbtn_var, bg="light gray", command=sh_v_mode)
acc_radbtn.select()
v_add_btn = Button(vlan_conf_frame, text="Add", font=tkFont.Font(size=10), command=add_allow_vlan)
v_del_btn = Button(vlan_conf_frame, text="Delete", font=tkFont.Font(size=10), command=del_allow_vlan)

#if_checkbutton
port_range_chkvar = tkinter.IntVar()
port_range_chk = Checkbutton(if_conf_frame, text="range", variable=port_range_chkvar, bg="light gray", command=select_range, font=tkFont.Font(size="12"))
port_range_chk.place(x=313, y=30)

nat_in = Label(if_conf_frame, text="- NAT in/out port : ", font=fontstyle, bg="light gray")
nat_in.place(x=15,y=135)

in_chkvar = tkinter.IntVar()
in_chk_btn = Checkbutton(if_conf_frame, text="In", variable=in_chkvar, bg="light gray", command=select_chk_in)
in_chk_btn.place(x=170,y=136)

out_chkvar = tkinter.IntVar()
out_chk_btn = Checkbutton(if_conf_frame, text="Out", variable=out_chkvar, bg="light gray", command=select_chk_out)
out_chk_btn.place(x=220,y=136)

none_chkvar = tkinter.IntVar()
none_chk_btn = Checkbutton(if_conf_frame, text="None", variable=none_chkvar, bg="light gray", command=select_chk_none)
none_chk_btn.place(x=275,y=136)
none_chk_btn.select()

dhcp_no_chkvar = tkinter.IntVar()
dhcp_chk_no = Checkbutton(if_conf_frame, text="Not use", variable=dhcp_no_chkvar, bg="light gray", command=chk_no)
dhcp_chk_no.place(x=173, y=172)
dhcp_chk_no.select()
dhcp_yes_chkvar = tkinter.IntVar()
dhcp_chk_yes = Checkbutton(if_conf_frame, text="Use", variable=dhcp_yes_chkvar, bg="light gray", command=chk_yes)
dhcp_chk_yes.place(x=243, y=172)

use_vlan_chkvar = tkinter.IntVar()
use_vlan_chk = Checkbutton(if_conf_frame, text="Apply", variable=use_vlan_chkvar ,font=boxfont, bg="light gray", command=show_vlan_frame)
use_vlan_chk.place(x=230,y=250)
#if_button
sum_if_btn = Button(if_conf_frame, text="커맨드 만들기", command=if_make, font=fontstyle)
sum_if_btn.place(x=274, y=657)
clear_if_btn = Button(if_conf_frame, text="모두 지우기", command=if_clear, font=fontstyle)
clear_if_btn.place(x=6, y=657)


#Button(root, text="선 택", command=select_option)

#NAT 설정 Frame
nat_conf_frame = Frame(root, width="393", height="700", bd=2, relief=RIDGE, background="light gray") 
nat_conf_frame.grid_forget()
nat = Label(nat_conf_frame, text="NAT", font=tkFont.Font(size=14, family="맑은 고딕"), bg="light gray")
nat_conf_frame.grid_propagate(0)
nat.place(x=1, y=1)

#OSPF 설정 Frame
ospf_conf_frame = Frame(root, width="393", height="700", bd=2, relief=RIDGE, background="light gray") 
ospf_conf_frame.grid_forget()
ospf = Label(ospf_conf_frame, text="OSPF", font=tkFont.Font(size=14, family="맑은 고딕"), bg="light gray")
ospf_conf_frame.grid_propagate(0)
ospf.place(x=1, y=1)


root.mainloop()